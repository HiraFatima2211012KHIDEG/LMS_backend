import React, { useState } from 'react';
import { IoIosArrowDown } from 'react-icons/io';
import StudentMarksTable from './StudentMarksTable'; // Make sure to import the components correctly

const Grading = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [openSection, setOpenSection] = useState(null);
    const [selected, setSelected] = useState(null); // Store the selected quiz

    const quiz = ['quiz1', 'quiz2', 'quiz3', 'quiz4'];

    const toggleOpen = (e) => {
        e.stopPropagation(); // Prevent click from bubbling up
        setIsOpen(!isOpen);
    };

    const handleSelect = (option) => {
        setSelected(option);
        // Keep the dropdown open after selecting a quiz
        setIsOpen(false);

    };

    const handleToggleSection = (section) => {
        setOpenSection(openSection === section ? null : section);
    };

    return (
        <div>
            <div className="border border-dark-300 w-full p-4 rounded-lg cursor-pointer flex flex-col ">
                <div
                    className="flex justify-between items-center"
                    onClick={() => handleToggleSection("Quiz")}
                >
                    <p className="text-[17px] font-semibold font-exo">Quiz</p>
                    <div className="flex gap-2 items-center">
                        <div
                            className={`transition-container ${openSection === "Quiz" ? "max-height-full" : "max-height-0"
                                }`}
                        >
                            {openSection === "Quiz" && (
                                <div className="z-20">
                                    <button
                                        onClick={toggleOpen}
                                        className="flex justify-between z-30 items-center min-w-[200px] text-[#92A7BE] hover:text-[#0e1721] px-4 py-2 text-sm text-left bg-white border  border-[#92A7BE] rounded-lg  focus:outline-none focus:ring-2 focus:ring-blue-300 transition duration-300 ease-in-out"
                                    >
                                        {selected || quiz[0]}
                                        <span className={`${!isOpen ? 'rotate-180 duration-300': 'duration-300'}`}>
                                            <IoIosArrowDown />
                                        </span>
                                    </button>

                                    {isOpen && (
                                        <div
                                            className="absolute capitalize z-40 min-w-[200px] mt-1 bg-surface-100 border border-dark-200 rounded-lg shadow-lg transition-opacity duration-300 ease-in-out"
                                            onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside the dropdown
                                        >
                                            {quiz.map((option, index) => (
                                                <div
                                                    key={index}
                                                    onClick={() => handleSelect(option)}
                                                    className="p-2 cursor-pointer"
                                                >
                                                    <div className="px-4 py-2 hover:bg-[#03a3d838] hover:text-[#03A1D8] hover:font-semibold rounded-lg">
                                                        {option}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                        <span className={`${openSection ? 'rotate-180 duration-300': 'duration-300'}`}>
                            <IoIosArrowDown />
                        </span>
                    </div>
                </div>
                {/* Render the component based on selected quiz */}
                {selected && openSection && (
                    <div className='mt-3'>
                        <StudentMarksTable /> {/* Correct rendering of the component */}
                    </div>
                )}
            </div>
        </div>

    );
};

export default Grading;
